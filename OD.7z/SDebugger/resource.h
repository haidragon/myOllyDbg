//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by SDebugger.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_SDebuggerTYPE               130
#define ID_WINDOW_MANAGER               131
#define IDS_WINDOWS_MANAGER             132
#define ID_VIEW_FILEVIEW                133
#define ID_VIEW_CLASSVIEW               134
#define ID_PROPERTIES                   135
#define ID_OPEN                         136
#define ID_OPEN_WITH                    137
#define ID_DUMMY_COMPILE                138
#define ID_CLASS_ADD_MEMBER_FUNCTION    139
#define ID_CLASS_ADD_MEMBER_VARIABLE    140
#define ID_CLASS_DEFINITION             141
#define ID_CLASS_PROPERTIES             142
#define ID_NEW_FOLDER                   143
#define ID_SORT_MENU                    144
#define ID_SORTING_GROUPBYTYPE          145
#define ID_SORTING_SORTALPHABETIC       146
#define ID_SORTING_SORTBYTYPE           147
#define ID_SORTING_SORTBYACCESS         148
#define ID_VIEW_OUTPUTWND               149
#define ID_VIEW_PROPERTIESWND           150
#define ID_SORTPROPERTIES               151
#define ID_PROPERTIES1                  152
#define ID_PROPERTIES2                  153
#define ID_EXPAND_ALL                   154
#define IDS_FILE_VIEW                   155
#define IDS_CLASS_VIEW                  156
#define IDS_OUTPUT_WND                  157
#define IDS_PROPERTIES_WND              158
#define IDS_REGISTER_WND                159
#define IDS_MODULE_VIEW                 160
#define IDI_FILE_VIEW                   161
#define IDS_INVOKE_STACK_WND            161
#define IDI_FILE_VIEW_HC                162
#define IDS_INVOKE_STACK_TAB            162
#define IDI_CLASS_VIEW                  163
#define IDS_THREAD_STACK_TAB            163
#define IDI_CLASS_VIEW_HC               164
#define IDS_EXECUTE_MODULE_WND          164
#define IDI_OUTPUT_WND                  165
#define IDI_OUTPUT_WND_HC               166
#define IDI_PROPERTIES_WND              167
#define IDI_PROPERTIES_WND_HC           168
#define IDR_EXPLORER                    169
#define IDB_EXPLORER_24                 170
#define IDR_SORT                        171
#define IDB_SORT_24                     172
#define IDR_POPUP_SORT                  173
#define IDR_POPUP_EXPLORER              174
#define IDB_FILE_VIEW                   175
#define IDB_FILE_VIEW_24                176
#define IDB_CLASS_VIEW                  177
#define IDB_CLASS_VIEW_24               178
#define IDR_MENU_IMAGES                 179
#define IDB_MENU_IMAGES_24              180
#define ID_TOOLS_MACRO                  181
#define IDR_OUTPUT_POPUP                182
#define IDR_PROPERTIES                  183
#define IDB_PROPERTIES_HC               184
#define IDS_SELF_TAB                    300
#define IDS_DEBUG_TAB                   301
#define IDS_ALL_TAB                     302
#define IDS_EXPLORER                    305
#define IDS_EDIT_MENU                   306
#define IDS_TOOLBAR_DEBUG               307
#define IDD_PROC_WND_DLG                310
#define ID_VIEW_REGISTERWND             311
#define ID_VIEW_INVOKESTACKWND          312
#define ID_VIEW_EXCUTEMODULEWND         313
#define IDR_DEBUGGER                    326
#define IDD_PROCESS_DLG                 328
#define IDC_PROC_WND_TREE               1001
#define IDC_PROGRESS_BAR                1002
#define IDC_INVOKE_STACK_TABLE          1003
#define IDC_THREAD_STACK_TABLE          1004
#define IDC_EXECUTE_MODULE_TABLE		1005
#define ID_ATTACH_PROCESS               32771
#define ID_CREATE_PROCESS               32772
#define ID_VIEW_MODULEVIEW              32773
#define ID_TREE_MODULETREE              32774
#define ID_RUN                          32799
#define ID_PAUSE                        32800
#define ID_STOP                         32801
#define ID_RESTART                      32802
#define ID_SINGLE_IN                    32803
#define ID_SINGLE_OVER                  32804
#define ID_SINGLE_RETURN                32805
#define ID_32806                        32806
#define ID_EXECUTE_MODULE               32807

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        329
#define _APS_NEXT_COMMAND_VALUE         32808
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
